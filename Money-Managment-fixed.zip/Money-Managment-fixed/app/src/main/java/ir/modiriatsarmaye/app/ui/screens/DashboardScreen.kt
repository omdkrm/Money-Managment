package ir.modiriatsarmaye.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.modiriatsarmaye.app.data.model.CurrencyType
import ir.modiriatsarmaye.app.data.model.TransactionEntity
import ir.modiriatsarmaye.app.ui.components.*
import ir.modiriatsarmaye.app.ui.theme.*
import ir.modiriatsarmaye.app.ui.viewmodel.WealthUiState
import ir.modiriatsarmaye.app.util.PersianUtils

@Composable
fun DashboardScreen(
    uiState: WealthUiState,
    onAddTransactionClick: () -> Unit,
    onNavigateToPortfolio: () -> Unit,
    onNavigateToTransactions: () -> Unit,
    onNavigateToReports: (Int) -> Unit,
    onTransactionClick: (TransactionEntity) -> Unit
) {
    val summary = uiState.portfolioSummary
    val settings = uiState.settings
    var hideAmounts by remember { mutableStateOf(settings.hideSensitiveAmounts) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("dashboard_screen")
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ۱. هدر داشبورد
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "مدیریت سرمایه",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "سامانه جامع پایش ثروت و پرتفوی",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                AppIconActionButton(
                    icon = if (hideAmounts) AppIcons.VisibilityOff else AppIcons.Visibility,
                    contentDescription = "مخفی‌سازی مبالغ",
                    onClick = { hideAmounts = !hideAmounts },
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
            }
        }

        // دیاگنوستیک بازار
        val lastReport = uiState.lastMarketUpdateReport
        if (lastReport != null && (lastReport.goldDiagnostics.isNotEmpty() || lastReport.pipelineDiagnostic != null)) {
            item {
                GoldDiagnosticCard(
                    diagnostics = lastReport.goldDiagnostics,
                    pipelineDiagnostic = lastReport.pipelineDiagnostic
                )
            }
        }

        // ۲. Hero Card — ارزش کل پرتفوی
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_hero_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ارزش کل سبد دارایی‌ها",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                        StatusBadge(
                            text = if (summary.totalReturnPct >= 0)
                                "+${PersianUtils.formatNumber(summary.totalReturnPct, 1)}٪"
                            else
                                "${PersianUtils.formatNumber(summary.totalReturnPct, 1)}٪",
                            color = if (summary.totalReturnPct >= 0) ProfitGreen else LossRed,
                            backgroundColor = if (summary.totalReturnPct >= 0)
                                ProfitGreen.copy(alpha = 0.18f)
                            else
                                LossRed.copy(alpha = 0.18f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (hideAmounts) "••••••••"
                        else PersianUtils.formatMoney(summary.totalPortfolioValueToman, settings.displayCurrency),
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "کل سرمایه‌گذاری‌شده",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (hideAmounts) "••••••"
                                else PersianUtils.formatMoney(summary.totalInvestedCostToman, settings.displayCurrency),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "سود / زیان کل",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (hideAmounts) "••••••"
                                else PersianUtils.formatMoney(summary.totalProfitLossToman, settings.displayCurrency),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (summary.totalProfitLossToman >= 0) ProfitGreen else LossRed
                            )
                        }
                    }
                }
            }
        }

        // ۳. کارت‌های شاخص‌های مالی
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                WealthMetricCard(
                    title = "دارایی خالص (Net Worth)",
                    value = if (hideAmounts) "••••••"
                    else PersianUtils.formatMoney(summary.netWorthToman, settings.displayCurrency),
                    subtitle = if (summary.totalLiabilitiesToman > 0)
                        "بدهی: ${PersianUtils.formatMoney(summary.totalLiabilitiesToman, settings.displayCurrency)}"
                    else "بدون بدهی ثبت‌شده",
                    icon = AppIcons.AccountBalance,
                    modifier = Modifier.weight(1f)
                )
                WealthMetricCard(
                    title = "سرمایه‌گذاری ماهانه",
                    value = if (hideAmounts) "••••••"
                    else PersianUtils.formatMoney(settings.monthlyInvestmentToman, settings.displayCurrency),
                    subtitle = "افزایش سالانه: ${PersianUtils.toPersianDigits(settings.annualInvestmentIncreasePct.toInt().toString())}٪",
                    icon = AppIcons.Savings,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // ۴. هشدار بازتنظیم
        if (summary.hasRebalanceAlert) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToReports(0) }
                        .testTag("rebalance_alert_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "نیاز به بازتنظیم پرتفوی",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "تخصیص برخی دارایی‌ها بیش از ۵٪ از هدف انحراف دارد.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                            )
                        }
                        Icon(
                            imageVector = AppIcons.ArrowForwardIos,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // ۵. ترکیب سبد دارایی‌ها
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("portfolio_composition_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ترکیب سبد دارایی‌ها",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        AppTextButton(
                            text = "مشاهده همه",
                            onClick = onNavigateToPortfolio,
                            modifier = Modifier.testTag("view_all_holdings_btn")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val hasPortfolioValue = summary.totalPortfolioValueToman > 0.0 && summary.holdings.isNotEmpty()
                    val validAllocations = summary.allocationByClass.entries
                        .filter { (_, pct) -> !pct.isNaN() && !pct.isInfinite() && pct > 0.05 }
                        .sortedByDescending { it.value }

                    if (!hasPortfolioValue || validAllocations.isEmpty()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .testTag("composition_empty_state"),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = AppIcons.PieChart,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.size(36.dp)
                                )
                                Text(
                                    text = "هنوز دارایی فعالی برای نمایش ثبت نشده است",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "با ثبت تراکنش‌های خرید، ترکیب درصدی دارایی‌ها اینجا نمایش داده می‌شود.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        // نوار گرافیکی
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            validAllocations.forEach { (assetClass, pct) ->
                                Box(
                                    modifier = Modifier
                                        .weight(pct.toFloat().coerceAtLeast(0.01f))
                                        .fillMaxHeight()
                                        .background(allocationColor(assetClass))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Column(
                            modifier = Modifier.fillMaxWidth().testTag("composition_legend_list"),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            validAllocations.forEach { (ac, pct) ->
                                val color = allocationColor(ac)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = ac.titleFa,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Text(
                                        text = "${PersianUtils.formatNumber(pct, 1)}٪",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = color
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ۶. پیش‌نمایش بازنشستگی
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToReports(1) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = AppIcons.Timeline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "شبیه‌ساز بازنشستگی (${PersianUtils.toPersianDigits(settings.retirementHorizonYears.toString())} ساله)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Icon(
                            imageVector = AppIcons.ArrowForwardIos,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "فرض شبیه‌سازی — نه پیش‌بینی قطعی بازار",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    val balancedScenario = uiState.retirementScenarios.getOrNull(1)
                    if (balancedScenario != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "سناریوی متعادل (${PersianUtils.toPersianDigits(settings.scenarioBalancedReturnPct.toInt().toString())}٪)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (hideAmounts) "••••••"
                                    else PersianUtils.formatMoney(balancedScenario.finalNominalValueToman, settings.displayCurrency),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "تعدیل‌شده با تورم",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (hideAmounts) "••••••"
                                    else PersianUtils.formatMoney(balancedScenario.finalRealValueToman, settings.displayCurrency),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldDark
                                )
                            }
                        }
                    }
                }
            }
        }

        // ۷. آخرین تراکنش‌ها
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "آخرین تراکنش‌ها",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                AppTextButton(
                    text = "همه (${PersianUtils.toPersianDigits(uiState.transactions.size.toString())})",
                    onClick = onNavigateToTransactions
                )
            }
        }

        if (uiState.transactions.isEmpty()) {
            item {
                EmptyStateView(
                    title = "تراکنشی ثبت نشده است",
                    description = "با دکمه «+ ثبت تراکنش» اولین خرید یا سرمایه‌گذاری خود را اضافه کنید.",
                    actionButtonText = "+ ثبت تراکنش",
                    onActionClick = onAddTransactionClick
                )
            }
        } else {
            items(uiState.transactions.take(4)) { tx ->
                TransactionCardItem(
                    transaction = tx,
                    displayCurrency = settings.displayCurrency,
                    hideAmounts = hideAmounts,
                    onClick = { onTransactionClick(tx) }
                )
            }
        }
    }
}

@Composable
private fun allocationColor(assetClass: ir.modiriatsarmaye.app.data.model.AssetClass): Color {
    return when (assetClass) {
        ir.modiriatsarmaye.app.data.model.AssetClass.GOLD,
        ir.modiriatsarmaye.app.data.model.AssetClass.GOLD_FUND -> GoldAccent
        ir.modiriatsarmaye.app.data.model.AssetClass.EQUITY_FUND,
        ir.modiriatsarmaye.app.data.model.AssetClass.STOCK -> EmeraldPrimary
        ir.modiriatsarmaye.app.data.model.AssetClass.FIXED_INCOME_FUND -> InfoBlue
        ir.modiriatsarmaye.app.data.model.AssetClass.USD,
        ir.modiriatsarmaye.app.data.model.AssetClass.EUR,
        ir.modiriatsarmaye.app.data.model.AssetClass.AED -> Color(0xFF0D9488)
        ir.modiriatsarmaye.app.data.model.AssetClass.CASH,
        ir.modiriatsarmaye.app.data.model.AssetClass.DEPOSIT -> Color(0xFF8B5CF6)
        else -> Color(0xFF6B7280)
    }
}

@Composable
fun TransactionCardItem(
    transaction: TransactionEntity,
    displayCurrency: CurrencyType,
    hideAmounts: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("transaction_item_${transaction.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                AssetClassBadge(assetClass = transaction.assetClass)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = transaction.assetName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "${transaction.action.titleFa} • ${PersianUtils.formatNumber(transaction.quantity)} ${transaction.unit} • ${transaction.datePersian}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                if (transaction.totalAmount != null) {
                    Text(
                        text = if (hideAmounts) "••••••"
                        else PersianUtils.formatMoney(transaction.totalAmount, transaction.currency),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (transaction.action) {
                            ir.modiriatsarmaye.app.data.model.TransactionAction.SELL -> ProfitGreen
                            ir.modiriatsarmaye.app.data.model.TransactionAction.WITHDRAWAL -> LossRed
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                    )
                    if (transaction.currency == CurrencyType.RIAL) {
                        Text(
                            text = PersianUtils.formatMoney(
                                PersianUtils.rialToToman(transaction.totalAmount),
                                CurrencyType.TOMAN
                            ),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    StatusBadge(
                        text = "قیمت نامشخص",
                        color = MaterialTheme.colorScheme.error,
                        backgroundColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                    )
                }
            }
        }
    }
}
