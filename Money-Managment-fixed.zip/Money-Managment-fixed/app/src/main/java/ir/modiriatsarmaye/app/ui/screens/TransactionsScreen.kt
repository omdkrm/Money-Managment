package ir.modiriatsarmaye.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.modiriatsarmaye.app.data.model.*
import ir.modiriatsarmaye.app.ui.components.*
import ir.modiriatsarmaye.app.ui.theme.*
import ir.modiriatsarmaye.app.ui.viewmodel.WealthUiState
import ir.modiriatsarmaye.app.util.PersianUtils

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TransactionsScreen(
    uiState: WealthUiState,
    onAddTransactionClick: () -> Unit,
    onEditTransaction: (TransactionEntity) -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit,
    onSearchChange: (String) -> Unit,
    onSelectClassFilter: (AssetClass?) -> Unit,
    onSelectActionFilter: (TransactionAction?) -> Unit
) {
    var transactionToDelete by remember { mutableStateOf<TransactionEntity?>(null) }
    val displayCurrency = uiState.settings.displayCurrency

    if (transactionToDelete != null) {
        ConfirmationDialog(
            title = "حذف تراکنش",
            message = "آیا از حذف تراکنش «${transactionToDelete!!.assetName}» به تاریخ «${transactionToDelete!!.datePersian}» اطمینان دارید؟ تمامی محاسبات پرتفوی پس از حذف مجدداً محاسبه خواهند شد.",
            confirmButtonText = "تایید و حذف",
            isDestructive = true,
            onConfirm = {
                onDeleteTransaction(transactionToDelete!!)
                transactionToDelete = null
            },
            onDismiss = { transactionToDelete = null }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // هدر
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "دفتر تراکنش‌ها",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "کل اطلاعات پرتفوی از این سوابق مشتق می‌شود",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                AppPrimaryButton(
                    text = "ثبت جدید",
                    onClick = onAddTransactionClick,
                    icon = Icons.Default.Add,
                    contentPadding = AppButtonDefaults.CompactContentPadding,
                    modifier = Modifier.testTag("add_transaction_top_btn")
                )
            }
        }

        // نوار جستجو
        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("جستجو در نام دارایی، نماد یا توضیحات...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (uiState.searchQuery.isNotBlank()) {
                        AppIconActionButton(
                            icon = Icons.Default.Clear,
                            contentDescription = "پاک کردن",
                            onClick = { onSearchChange("") }
                        )
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("transaction_search_input"),
                shape = RoundedCornerShape(12.dp)
            )
        }

        // فیلتر دسته دارایی
        item {
            Column {
                Text(
                    text = "فیلتر دسته دارایی:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("filter_row_asset_classes")
                ) {
                    item {
                        AppFilterChip(
                            selected = uiState.selectedAssetClassFilter == null,
                            onClick = { onSelectClassFilter(null) },
                            label = "همه دسته‌ها",
                            modifier = Modifier.testTag("filter_chip_class_all")
                        )
                    }
                    items(AssetClass.entries) { ac ->
                        AppFilterChip(
                            selected = uiState.selectedAssetClassFilter == ac,
                            onClick = { onSelectClassFilter(if (uiState.selectedAssetClassFilter == ac) null else ac) },
                            label = ac.titleFa,
                            modifier = Modifier.testTag("filter_chip_class_${ac.name}")
                        )
                    }
                }
            }
        }

        // فیلتر نوع عملیات
        item {
            Column {
                Text(
                    text = "فیلتر نوع عملیات:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth().testTag("filter_flowrow_transaction_actions"),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppFilterChip(
                        selected = uiState.selectedActionFilter == null,
                        onClick = { onSelectActionFilter(null) },
                        label = "همه عملیات",
                        modifier = Modifier.testTag("filter_chip_action_all")
                    )
                    TransactionAction.entries.forEach { act ->
                        val isSelected = uiState.selectedActionFilter == act
                        AppFilterChip(
                            selected = isSelected,
                            onClick = { onSelectActionFilter(if (isSelected) null else act) },
                            label = act.titleFa,
                            modifier = Modifier.testTag("filter_chip_action_${act.name}")
                        )
                    }
                }
            }
        }

        // تعداد نتایج
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${PersianUtils.toPersianDigits(uiState.filteredTransactions.size.toString())} تراکنش منطبق",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (uiState.filteredTransactions.size != uiState.transactions.size) {
                    Text(
                        text = "از ${PersianUtils.toPersianDigits(uiState.transactions.size.toString())} کل",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }
        }

        // لیست تراکنش‌ها
        if (uiState.filteredTransactions.isEmpty()) {
            item {
                EmptyStateView(
                    title = "تراکنشی یافت نشد",
                    description = "با توجه به فیلترها یا جستجوی فعلی، تراکنشی پیدا نشد.",
                    actionButtonText = "+ ثبت تراکنش جدید",
                    onActionClick = onAddTransactionClick
                )
            }
        } else {
            items(uiState.filteredTransactions, key = { it.id }) { tx ->
                TransactionDetailCard(
                    transaction = tx,
                    displayCurrency = displayCurrency,
                    onEdit = { onEditTransaction(tx) },
                    onDelete = { transactionToDelete = tx }
                )
            }
        }
    }
}

@Composable
fun TransactionDetailCard(
    transaction: TransactionEntity,
    displayCurrency: CurrencyType,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val actionColor = when (transaction.action) {
        TransactionAction.BUY -> MaterialTheme.colorScheme.primary
        TransactionAction.SELL -> ProfitGreen
        TransactionAction.DIVIDEND -> GoldDark
        TransactionAction.DEPOSIT -> InfoBlue
        TransactionAction.WITHDRAWAL -> LossRed
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tx_card_${transaction.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // هدر: نوع دارایی + نام + عملیات
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    AssetClassBadge(assetClass = transaction.assetClass)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = transaction.assetName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                StatusBadge(
                    text = transaction.action.titleFa,
                    color = actionColor,
                    backgroundColor = actionColor.copy(alpha = 0.12f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // مقدار + قیمت
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "مقدار",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${PersianUtils.formatNumber(transaction.quantity)} ${transaction.unit}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (transaction.unitPrice != null) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "هر واحد: ${PersianUtils.formatMoney(transaction.unitPrice, transaction.currency)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "قیمت واحد: نامشخص",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "مبلغ کل",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    if (transaction.totalAmount != null) {
                        Text(
                            text = PersianUtils.formatMoney(transaction.totalAmount, transaction.currency),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (transaction.currency == CurrencyType.RIAL) {
                            Text(
                                text = "≈ ${PersianUtils.formatMoney(PersianUtils.rialToToman(transaction.totalAmount), CurrencyType.TOMAN)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        StatusBadge(
                            text = "قیمت خالی است",
                            color = MaterialTheme.colorScheme.error,
                            backgroundColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // تاریخ + کارگزاری
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "📅 ${transaction.datePersian}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (transaction.brokerOrSource.isNotBlank()) {
                    Text(
                        text = "منبع: ${transaction.brokerOrSource}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (transaction.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = transaction.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            TransactionCardActionRow(
                editLabel = if (transaction.unitPrice == null) "تکمیل قیمت خرید" else "ویرایش",
                onEdit = onEdit,
                onDelete = onDelete,
                editTestTag = "edit_tx_${transaction.id}",
                deleteTestTag = "delete_tx_${transaction.id}"
            )
        }
    }
}
