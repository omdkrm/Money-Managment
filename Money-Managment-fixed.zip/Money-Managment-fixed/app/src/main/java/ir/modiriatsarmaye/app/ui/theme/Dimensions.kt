package ir.modiriatsarmaye.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/**
 * ثابت‌های ابعاد و شکل‌های UI برای یکسان‌سازی ظاهر در تمام صفحات
 * استفاده از این ثابت‌ها به جای مقادیر مستقیم dp باعث یکپارچگی کامل می‌شود
 */
object AppDimensions {

    // ===== گوشه‌های گرد کارت‌ها =====
    /** کارت‌های اصلی (پرتفو، داشبورد، بیشتر) */
    val CardCornerRadius = 16.dp
    val CardShape = RoundedCornerShape(CardCornerRadius)

    /** کارت‌های داخلی و فرزند */
    val InnerCardCornerRadius = 12.dp
    val InnerCardShape = RoundedCornerShape(InnerCardCornerRadius)

    /** Badge و برچسب‌های کوچک */
    val BadgeCornerRadius = 8.dp
    val BadgeShape = RoundedCornerShape(BadgeCornerRadius)

    // ===== padding داخلی کارت‌ها =====
    /** padding استاندارد داخل کارت‌های اصلی */
    val CardPadding = 16.dp

    /** padding کارت‌های فرزند و داخلی */
    val InnerCardPadding = 12.dp

    /** padding افقی صفحات */
    val ScreenHorizontalPadding = 16.dp

    /** فاصله بین آیتم‌ها در LazyColumn */
    val ListItemSpacing = 16.dp

    /** padding پایین لیست (برای ناوبری پایین) */
    val ListBottomPadding = 96.dp

    // ===== سایه کارت‌ها =====
    /** سایه استاندارد کارت‌های اصلی */
    val CardElevation = 2.dp

    /** سایه کارت‌های فرعی */
    val SubCardElevation = 1.dp

    // ===== فاصله‌های عمودی داخل کارت‌ها =====
    val SpacingXS = 4.dp
    val SpacingS = 6.dp
    val SpacingM = 8.dp
    val SpacingL = 10.dp
    val SpacingXL = 12.dp
    val SpacingXXL = 16.dp
}
